<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => ' ', ',', '.', '"', '[JIS]', '"', '/', 'ling', '<', '>', '<<', '>>', '[', '] ', '{', '} ',
  0x10 => '[(', ')] ', '@', 'X ', '[', ']', '[[', ']] ', '[', ']', '[', ']', '~ ', '"', '"', ',,',
  0x20 => '@', '1', '2', '3', '4', '5', '6', '7', '8', '9', '', '', '', '', '', '',
  0x30 => '~', '+', '+', '+', '+', '', '@', ' // ', 'shi', 'nian', 'sa', NULL, NULL, NULL, '', '',
  0x40 => NULL, '~a', 'a', '~i', 'i', '~u', 'u', '~e', 'e', '~o', 'o', 'ka', 'ka', 'ki', 'ki', 'ku',
  0x50 => 'ku', 'ke', 'ke', 'ko', 'ko', 'sa', 'sa', 'shi', 'shi', 'su', 'su', 'se', 'se', 'so', 'so', 'ta',
  0x60 => 'ta', 'chi', 'chi', '~tsu', 'tsu', 'tsu', 'te', 'te', 'to', 'to', 'na', 'ni', 'nu', 'ne', 'no', 'ha',
  0x70 => 'ha', 'ha', 'hi', 'hi', 'hi', 'fu', 'fu', 'fu', 'he', 'he', 'he', 'ho', 'ho', 'ho', 'ma', 'mi',
  0x80 => 'mu', 'me', 'mo', '~ya', 'ya', '~yu', 'yu', '~yo', 'yo', 'ra', 'ri', 'ru', 're', 'ro', '~wa', 'wa',
  0x90 => 'wi', 'we', 'wo', 'n', 'u', NULL, NULL, NULL, NULL, '', '', '', '', '"', '"', NULL,
  0xA0 => NULL, '~a', 'a', '~i', 'i', '~u', 'u', '~e', 'e', '~o', 'o', 'ka', 'ka', 'ki', 'ki', 'ku',
  0xB0 => 'ku', 'ke', 'ke', 'ko', 'ko', 'sa', 'sa', 'shi', 'shi', 'su', 'su', 'se', 'se', 'so', 'so', 'ta',
  0xC0 => 'ta', 'chi', 'chi', '~tsu', 'tsu', 'tsu', 'te', 'te', 'to', 'to', 'na', 'ni', 'nu', 'ne', 'no', 'ha',
  0xD0 => 'ha', 'ha', 'hi', 'hi', 'hi', 'fu', 'fu', 'fu', 'he', 'he', 'he', 'ho', 'ho', 'ho', 'ma', 'mi',
  0xE0 => 'mu', 'me', 'mo', '~ya', 'ya', '~yu', 'yu', '~yo', 'yo', 'ra', 'ri', 'ru', 're', 'ro', '~wa', 'wa',
  0xF0 => 'wi', 'we', 'wo', 'n', 'u', '~ka', '~ke', 'wa', 'wi', 'we', 'wo', '', '', '"', '"', NULL,
];
